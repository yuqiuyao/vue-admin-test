<template>
  <div>
    <template> 
      <!-- <div v-for="(item1 , index1) in this.num" :key="index1"> -->
             <el-radio v-for="(item , index) in this.radio_Data" :key="index" v-model="radio" :label="index">{{item}}</el-radio>
      <!-- </div>    -->
      <el-radio v-model="radio" label="4">备选项</el-radio>
      <el-radio v-model="radio" label="5">备选项</el-radio>
    </template>
      <!-- <img :src="this.Img" alt=""> -->
     <div id="allmap" ref="allmap"></div>

         
  </div>
</template>

<script>
export default {
  name: 'Shop',
  data () {
    return {
        radio: '1',
        radio_Data:["选项一","选项二","选项三"],
        Img: require('../../static/img/location.png')
    }
  },
  methods:{
    map(){
      var map = new BMap.Map("allmap");          // 创建地图实例  
        var point = new BMap.Point(104.06, 30.67);  // 创建点坐标  
        var marker = new BMap.Marker(point); 
        map.centerAndZoom(point, 15);                 // 初始化地图，设置中心点坐标和地图级别  
        map.enableScrollWheelZoom(true); 
        map.addControl(new BMap.NavigationControl());    
        map.addControl(new BMap.ScaleControl());    
        map.addControl(new BMap.OverviewMapControl());    
        map.addControl(new BMap.MapTypeControl());  


        //创建小狐狸
        var pt = new BMap.Point(104.06, 30.67);
        var myIcon = new BMap.Icon("http://lbsyun.baidu.com/jsdemo/img/fox.gif", new BMap.Size(300,157));
        var marker2 = new BMap.Marker(pt,{icon:myIcon});  // 创建标注
        map.addOverlay(marker2);              // 将标注添加到地图中


        // 缩略图
       var mapType1 = new BMap.MapTypeControl(
          {
            mapTypes: [BMAP_NORMAL_MAP,BMAP_HYBRID_MAP],
            anchor: BMAP_ANCHOR_TOP_LEFT
          }
        );

        var overView = new BMap.OverviewMapControl();
        var overViewOpen = new BMap.OverviewMapControl({isOpen:true, anchor: BMAP_ANCHOR_BOTTOM_RIGHT});
        map.addControl(mapType1);          //2D图，混合图
        map.addControl(overView);          //添加默认缩略地图控件
        map.addControl(overViewOpen);      //右下角，打开


      //  城市切换o
      // map.enableInertialDragging();

      // map.enableContinuousZoom();

      // var size = new BMap.Size(10, 20);
      // map.addControl(new BMap.CityListControl({
      //     anchor: BMAP_ANCHOR_TOP_LEFT,
      //     offset: size,
      // }));
     }
 
  },
  mounted(){
    this.map();
  }       
  }
</script>

<style scoped>

#allmap{
  height: 500px;
  overflow: normal;
}
</style>
