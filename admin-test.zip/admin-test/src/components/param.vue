<template>
  <div>
        <el-button :type="button">主要按钮</el-button>
        <p>这是参数:{{needNum}}</p>
  </div>
</template>

<script>
export default {
  name: "param",
  data () {
    return {
      needNum:'',
      button:''
    }
  },
  created(){
    console.log('参数获取-----',this.$route.query.id)   //this.$route.query.id

    // this.needNum = this.$route.params.id;
    // this.button = this.$route.params.btnType;
     this.needNum = this.$route.query.id;
     this.button = this.$route.query.btnType;
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
