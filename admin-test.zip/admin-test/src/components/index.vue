<template>
  <div>
        <el-button type="primary"  @click="clickBtn(1)">按钮1</el-button>
        <el-button type="success"  @click="clickBtn(2)">按钮2</el-button>
        <el-button type="info"     @click="clickBtn(3)">按钮3</el-button>
        <el-button type="warning"  @click="clickBtn(4)">按钮4</el-button>
        <el-button type="danger"   @click="clickBtn(5)">按钮5</el-button>
  </div>
</template>

<script>
export default {
  name: "index",
  data () {
    return {
      needNum:'',
      btntype:''
    }
  },
   methods:{
     clickBtn(num){   
       if(num==1){
         this.btntype="primary"
       }else if(num==2){
         this.btntype="success"
       }else if(num==3){
         this.btntype="info"
       }else if(num==4){
         this.btntype="warning"
       }else if(num==5){
         this.btntype="danger"
       }
          // this.$router.push({name:'canshu',params:{id:num,btnType:this.btntype}})      //params传参  name
           this.$router.push({path:'/param',  query:{id:num,btnType:this.btntype}})    // query传参 path  
     }
   }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
