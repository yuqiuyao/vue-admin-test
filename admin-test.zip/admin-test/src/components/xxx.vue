<template>
<el-row>
  <el-col :span="4"><div class="grid-content ">&nbsp;</div></el-col>
  <el-col :span="16">
    <div class="grid-content ">
               <div class="edit_container">
                <quill-editor 
                    v-model="content" 
                    ref="myQuillEditor" 
                    :options="editorOption" 
                    @blur="onEditorBlur($event)" @focus="onEditorFocus($event)"
                    @change="onEditorChange($event)"
                    >
                </quill-editor>
              </div>
           <el-button type="primary" v-on:click="getData">主要按钮</el-button>
    </div>
    </el-col>

  <el-col :span="4"><div class="grid-content ">&nbsp;</div></el-col>
</el-row>

</template>

<script>
import { quillEditor } from "vue-quill-editor"; //调用编辑器
import 'quill/dist/quill.core.css';
import 'quill/dist/quill.snow.css';
import 'quill/dist/quill.bubble.css';
export default {
  name: 'XXX',
  data () {
    return {
            content: `<p></p><p><br></p><ol><li><strong><em>Or drag/paste an image here.</em></strong></li><li><strong><em>rerew</em></strong></li><li><strong><em>rtrete</em></strong></li><li><strong><em>tytrytr</em></strong></li><li><strong><em>uytu</em></strong></li></ol>`,
            editorOption: {},
            str: ''
    }
  },
  components: {
        quillEditor
    },
    methods: {
        onEditorReady(editor) { // 准备编辑器
 
        },
        onEditorBlur(){}, // 失去焦点事件
        onEditorFocus(){}, // 获得焦点事件
        onEditorChange(){}, // 内容改变事件
        // 转码
        escapeStringHTML(str) {
            str = str.replace(/</g,'<');
            str = str.replace(/>/g,'>');
            return str;
        },

        getData(){
           
            let content = '';  // 请求后台返回的内容字符串
            this.str = this.escapeStringHTML(content);
             console.log("测试数据",this.str,this.content);
        }
    },
    computed: {
        editor() {
            return this.$refs.myQuillEditor.quill;
        }
    },
     mounted() {
        let content = '';  // 请求后台返回的内容字符串
        this.str = this.escapeStringHTML(content);
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.quill-editor {
/* height: 300px; */
}
</style>
