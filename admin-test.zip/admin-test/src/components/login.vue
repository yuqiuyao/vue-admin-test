<template>
<div style="width:100%;height:100%;background:url(../../static/img/bg.jpg) no-repeat;background-size:100% 100%; background-attachment: fixed;">
 
<el-row>
  <el-col :span="9"><div class="grid-content ">&nbsp;</div></el-col>
  <el-col :span="6">
    <div  style="margin-top:60%;">
       <el-form :label-position="labelPosition" :rules="rules" label-width="80px" :model="formLabelAlign" style="padding: 50px 20px 30px 20px;background-color:rgba(255,255,255,0.6)">
        <el-form-item label="账号" prop="name">
          <el-input v-model="formLabelAlign.name"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="formLabelAlign.password" type="password"></el-input>
        </el-form-item>
        <el-form-item label="">
            <el-button type="primary" plain  @click="vueTest">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </el-col>
  <el-col :span="9"><div class="grid-content">&nbsp;</div></el-col>
</el-row>
</div>
</template> 

<script>
import store from '@/store/store'
export default {
  name: "login",
   data() {
     return{
        labelPosition: 'left',
        formLabelAlign: {
          name: '',
          password: '',
        },
        bg_img: require('../../static/img/bg.jpg'),
        rules: {
          name: [
            { required: true, message: '请输入账号', trigger: 'blur' },
            { min: 4, max: 10, message: '长度在 4 到 10 个字符', trigger: 'blur' }
          ],
          password: [
             { required: true, message: '请输入密码', trigger: 'blur' },
             { min: 4, max: 10, message: '长度在 4 到 10 个字符', trigger: 'blur' }
          ]
        }
     }
    },
    methods:{
      loginEven() {
          if (this.formLabelAlign.name==="admin" && this.formLabelAlign.password==="44A10123") {
            // this.$router.push({path:'/message'})
            window.localStorage.setItem("username","");
            //  this.$store.commit('getname',{name: this.formLabelAlign.name});
             this.$store.dispatch("getnameForMutation",this.formLabelAlign.name);
            this.$router.push({path:'/message'})
            console.log(this.$store.state.name)
            window.localStorage.setItem("username",this.formLabelAlign.name);
          } else {
            this.open6();
            return false;
          }
      },
      open6() {
        this.$notify.error({
          title: '账号或密码错误',
          message: '请检查是否输入正确'
        });
      },
      vueTest(){
        this.loginEven();
      }
    }
}
</script>
  
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
