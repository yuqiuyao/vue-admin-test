<template>
  <div style="height:100%;width:100%;" class='messageBox'>
      <p class="navTitle"> 
        <el-row>
          <el-col :span="18">
            <div class="grid-content ">
               <el-breadcrumb separator-class="el-icon-arrow-right" style="padding-top:15px;">
                <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
                <el-breadcrumb-item v-for="(item , index) in $route.meta" :key="index">{{item}}</el-breadcrumb-item>
              </el-breadcrumb>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="grid-content ">
                  <a href="#">vuex状态:{{username}}</a>&nbsp;&nbsp;<span>local存储:{{localName}}&nbsp;欢迎你</span>&nbsp;&nbsp;<el-button type="text" @click="exit">注销</el-button>
            </div>
         </el-col>
        </el-row>
      </p>
      <el-col :span="5" class='navMenu'>
            <el-menu
              default-active="2"
              class="el-menu-vertical-demo"
              @open="handleOpen"
              @close="handleClose"
              background-color="#545c64"
              text-color="#fff"
              active-text-color="#ffd04b"
              router
              >
              <el-menu-item index="index">
                <i class="el-icon-menu"></i>
                <span slot="title">首页</span>
              </el-menu-item>
              <el-submenu index="1">
                <template slot="title">
                  <i class="el-icon-location"></i>
                  <span>导航一</span>
                </template>
                <el-menu-item-group>
                  <el-menu-item index="shop">地图</el-menu-item>
                  <el-menu-item index="xxx">富文本</el-menu-item>
                  <el-menu-item index="test">表单</el-menu-item>
                  <el-menu-item index="mock">mock</el-menu-item>
                </el-menu-item-group>
              </el-submenu>
              <el-submenu index="2">
                <template slot="title">
                  <i class="el-icon-menu"></i>
                  <span slot="title">导航二</span>
                </template>
              </el-submenu>
              <el-submenu index="3" >
                 <template slot="title">
                  <i class="el-icon-document"></i>
                  <span slot="title">导航三</span>
                </template>  
              </el-submenu>
              <el-submenu index="4">
                 <template slot="title">
                   <i class="el-icon-setting"></i>
                   <span slot="title">个人中心</span>
                </template>  
                <el-menu-item-group>
                  <el-menu-item index="person">个人中心</el-menu-item>
                </el-menu-item-group>
              </el-submenu>
              <!-- <el-submenu index="">
                <template slot="title">
                  <i class="el-icon-location"></i>
                  <span>导航一</span>
                </template>
                <el-menu-item-group>
                  <el-menu-item index="shop">商品</el-menu-item>
                  <el-menu-item index="xxx">XXX</el-menu-item>
                  <el-menu-item index="test">测试</el-menu-item>
                </el-menu-item-group>
              </el-submenu> -->
            </el-menu>
      </el-col>
      <el-col :span="19">
            <router-view></router-view>
        </el-col>
  </div>
</template>

<script>
import store from '@/store/store'
export default {
  name: 'Message',
  data () {
    return {
      username:'',
      localName:""
    }
  },
  methods: {
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      },
      exit() {
        this.$confirm('此操作将退出系统, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({
            type: 'success',
            message: '退出成功!'
          });
          this.$store.commit('getname',{name: ""});
         this.$router.push({path:'/'})
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消退出'
          });          
        });
      }
    },
    created(){
      this.username = this.$store.state.name;
      this.localName= window.localStorage.getItem("username");
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
 .messageBox .navMenu{
   height: 100%;
   background-color: #545C64;
 }
 .navTitle{
   width: 100%;
   height: 50px;
   background-color: pink;
 }
 .el-menu {
    border-right: none;
}
</style>
