<template>
  <div>
     <el-row>
  <el-col :span="4"><div class="grid-content ">&nbsp;</div></el-col>
  <el-col :span="16">
      <div class="grid-content" style="margin-top:15px;">
          <el-form ref="form" :model="form" label-width="80px" >
          <div v-for="(item,index) in this.mockData" :key="index">
              <el-form-item :label="'标题'+index">
                <el-input :value ="item.title"></el-input>
              </el-form-item>
          </div>
            <el-form-item>
              <el-button type="primary" @click="onSubmit(form)">立即创建</el-button>
              <el-button type="primary" @click="clickShow">显示</el-button>
              <el-button @click="clickShow2">取消</el-button>
            </el-form-item>
          </el-form>
          <el-collapse v-model="activeNames" @change="handleChange" v-show="isShow == 1" > 
            <el-collapse-item title="活动名称" name="1">
              <div>与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念；</div>
              <div>在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。</div>
            </el-collapse-item>
            <el-collapse-item title="活动区域" name="2">
            </el-collapse-item>
            <el-collapse-item title="活动时间" name="3">
            </el-collapse-item>
            <el-collapse-item title="活动性质" name="4">
            </el-collapse-item>
            <el-collapse-item title="特殊资源" name="4">
            </el-collapse-item>
            <el-collapse-item title="活动形式" name="4">
            </el-collapse-item>
          </el-collapse>
      </div>
  </el-col>
  <el-col :span="4"><div class="grid-content ">&nbsp;</div></el-col>
</el-row>
  </div>
</template>

<script>
export default {
  name: 'mock',
  data () {
    return {
      mockData:[],
      activeNames: [''],
      isShow: 2,
      writeData:[],
     form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        }
    }
  },
  methods: {
      onSubmit(val) {
          console.log(val)
          let name = val.name,area = val.region,time=val.date1,resource =val.resource,type=val.type[0],desc=val.desc;
          this.writeData=[name,area,time,resource,type,desc];
          console.log(this.writeData)
             
      },
      handleChange(val) {
        console.log(val);
      },
      clickShow2(){
          if(this.isShow===1){ 
           this.isShow = 2
         }
      },
      clickShow(){
          if(this.isShow !==1){ 
           this.isShow = 1
         }
      }
    },
    created(){
            this.$http.get("/posts").then(res => {
              this.mockData = res.data.posts;
                console.log(res.data.posts);
            });
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
