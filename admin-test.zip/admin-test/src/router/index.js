import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Message from '@/components/Message'
import Shop from '@/components/shop'
import XXX from '@/components/xxx'
import Test from '@/components/test'
import Index from '@/components/index'
import param from '@/components/param'
import Login from '@/components/login'
import person from '@/components/person'
import mock from '@/components/mock'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'login',
      component: Login
    },
    // {
    //   path: '/',
    //   name: 'Message',
    //   component: Message
    // },
    {
      path: '/message',
      name: 'Message',
      component: Message,
      children:[
          {
            path: '/',
            name: 'index',
            component: Index,
            meta:['首页']
          },
          {
            path: '/index',
            name: 'index',
            component: Index,
            meta:['首页']
          },
          {
            path: '/shop',
            name: 'Shop',
            component: Shop,
            meta:["地图","map"]
          },
          {
            path: '/xxx',
            name: 'XXX',
            component: XXX,
            meta:["测试","富文本"]
          },
          {
            path: '/test',
            name: 'Test',
            component: Test,
            meta:["测试","test"]
          },
          {
            path: '/mock',
            name: 'mock',
            component: mock,
            meta:["测试","mock"]
          },
          {
            path: '/param',   // path: '/canshu'
            name: 'param',
            component: param,
            meta:["测试","参数"]
          },
          {
            path: '/person',  
            name: 'person',
            component: person,
            meta:["个人中心","个人中心"]
          }
      ]
    }
  ]
})
